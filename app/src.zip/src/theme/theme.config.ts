// export const BASEURL = 'http://sapi.bainid.com';
// export const BASEURL = 'http://sadmin.bainid.com';
export const BASEURL = 'http://101.132.70.102/api/index.php';
export const BASEURLIMG = 'http://101.132.70.102';

//export const BASEURL = 'http://api.skullfang.online';
// export const BASEURL = 'http://www.api.skullfang.cn';
// export const BASEURL = 'http://101.201.238.157';
export const TOREBASEURL = 'https://jsonplaceholder.typicode.com';
