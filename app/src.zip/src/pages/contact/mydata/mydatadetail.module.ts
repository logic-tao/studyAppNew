import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MydatadetailPage } from './mydatadetail';

@NgModule({
  declarations: [
    MydatadetailPage,
  ],
  imports: [
    IonicPageModule.forChild(MydatadetailPage),
  ],
})
export class MydatadetailPageModule {}
