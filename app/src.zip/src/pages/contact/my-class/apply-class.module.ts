import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ApplyClassPage } from './apply-class';

@NgModule({
  declarations: [
    ApplyClassPage,
  ],
  imports: [
    IonicPageModule.forChild(ApplyClassPage),
  ],
})
export class ApplyClassPageModule {}
