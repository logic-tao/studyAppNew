import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { VideorecordPage } from './videorecord';

@NgModule({
  declarations: [
    VideorecordPage,
  ],
  imports: [
    IonicPageModule.forChild(VideorecordPage),
  ],
})
export class VideorecordPageModule {}
