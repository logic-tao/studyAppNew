import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Pageexam01Page } from './pageexam01';

@NgModule({
  declarations: [
    Pageexam01Page,
  ],
  imports: [
    IonicPageModule.forChild(Pageexam01Page),
  ],
})
export class Pageexam01PageModule {}
