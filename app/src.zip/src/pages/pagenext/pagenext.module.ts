import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PagenextPage } from './pagenext';

@NgModule({
  declarations: [
    PagenextPage,
  ],
  imports: [
    IonicPageModule.forChild(PagenextPage),
  ],
})
export class PagenextPageModule {}
