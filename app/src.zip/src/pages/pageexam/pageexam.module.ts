import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PageexamPage } from './pageexam';

@NgModule({
  declarations: [
    PageexamPage,
  ],
  imports: [
    IonicPageModule.forChild(PageexamPage),
  ],
})
export class PageexamPageModule {}
