/**
 * Created by sundaowei on 17/8/8.
 */
import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-interaction',
  templateUrl: 'interaction.html'
})
export class InteractPage {

  constructor(public navCtrl: NavController) {

  }

}
