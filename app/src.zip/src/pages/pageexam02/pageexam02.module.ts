import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Pageexam02Page } from './pageexam02';

@NgModule({
  declarations: [
    Pageexam02Page,
  ],
  imports: [
    IonicPageModule.forChild(Pageexam02Page),
  ],
})
export class Pageexam02PageModule {}
