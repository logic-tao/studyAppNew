import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PagedetailPage } from './pagedetail';

@NgModule({
  declarations: [
    PagedetailPage,
  ],
  imports: [
    IonicPageModule.forChild(PagedetailPage),
  ],
})
export class PagedetailPageModule {}
