import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {Http,Response} from "@angular/http";
import {ExerciseDetailPage} from "./exercise-detail";
import {CoreProvider} from "../../../providers/core/core";

/**
 * Generated class for the ExercisePage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-exercise',
  templateUrl: 'exercise.html',
})
export class ExercisePage {

  // 接收数据
  listData: Object;
  // 课程
  subject: string ="1";


  constructor(public navCtrl: NavController, public navParams: NavParams,private  http: Http, private coreService: CoreProvider) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ExercisePage');
    // 网络请求
    //http://js onplaceholder.typicode.com/photos


    this.http.request(this.coreService.baseUrl)
      .subscribe((res: Response) => {
        this.listData = res.json();
      });
  }

  itemSelected(item){
    this.navCtrl.push(ExerciseDetailPage,{subject:item});
  }

}
